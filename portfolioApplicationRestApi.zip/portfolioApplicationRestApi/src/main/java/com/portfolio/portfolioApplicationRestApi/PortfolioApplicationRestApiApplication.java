package com.portfolio.portfolioApplicationRestApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioApplicationRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioApplicationRestApiApplication.class, args);
		System.out.println("Hello");
	}

}
